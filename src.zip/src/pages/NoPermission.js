import React, { Component } from "react";

class NoPermission extends Component {
  render() {
    return <div>this is 403 page</div>;
  }
}

export default NoPermission;
