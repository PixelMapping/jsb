import React, { Component } from "react";

class NoMatch extends Component {
  render() {
    return <div>404 no found </div>;
  }
}

export default NoMatch;
