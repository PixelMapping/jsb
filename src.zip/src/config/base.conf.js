export default {
  company: "简税宝税务筹划系统",
  title: "简税宝税务筹划系统",
  subTitle: "简税宝税务筹划系统",
  enTitle: "xushanpei Manage platform",
  copyright: "Copyright © 2019 shunbega All Rights Reserved.",
  logo: require("../assets/image/jsb-logoX.png"),  
  // baseUrl: "http://47.116.4.10:8780",
  baseUrl:"/api",
  persist: "root"
};
